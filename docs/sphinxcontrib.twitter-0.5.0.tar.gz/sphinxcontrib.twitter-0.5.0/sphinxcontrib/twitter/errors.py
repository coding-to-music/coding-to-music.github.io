#-*- coding:utf-8 -*-


from sphinx import errors



class TwitterError(errors.SphinxError):
    category = 'Sphinxcontrib.Twitter error'
